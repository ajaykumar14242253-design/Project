# RetailPulse 360 — Instacart Market Basket Analytics

An end-to-end retail analytics portfolio project built around the [Instacart Market Basket Analysis dataset](https://www.kaggle.com/datasets/psparks/instacart-market-basket-analysis/data).

The project demonstrates data quality checks, relational data modeling, customer and product behavior analysis, market-basket metrics, SQL analysis, and dashboard-ready outputs.

> **Data honesty:** The Instacart files describe orders and product-line behavior. They do **not** provide prices, revenue, product costs, marketing spend, discounts, customer geography, or calendar transaction dates. This repository therefore does not fabricate sales, profit, ROI, regional, or currency-based CLV metrics.

## Project highlights

- Validate source schemas, key uniqueness, value ranges, and foreign-key integrity.
- Preserve the distinction between `prior`, `train`, and `test` order populations.
- Build clean, enriched order-product data with explicit source-split labels.
- Calculate reorder rate, observed basket size, product popularity, order timing, and repeat-order behavior.
- Provide SQL examples and Power BI DAX measures for a reproducible dashboard.
- Explore market-basket rules using support, confidence, lift, leverage, and conviction.

## Tools

- **Python:** pandas, NumPy
- **SQL:** portable analytical queries (minor dialect adjustments may be required)
- **Power BI:** data model and DAX measures
- **Power Query:** M examples in `docs/POWER_QUERY.md`
- **Excel:** formula reference in `docs/FORMULAS.md`

## Dataset

Download the files from Kaggle and place them in `data/raw/`:

```text
data/raw/
├── orders.csv
├── order_products__prior.csv
├── order_products__train.csv
├── products.csv
├── aisles.csv
└── departments.csv
```

Do not commit the original Kaggle data unless its license and terms explicitly permit redistribution. This repository intentionally excludes the dataset files.

## Quick start

### 1. Create an environment

```bash
python -m venv .venv
# Windows PowerShell:
.venv\Scripts\Activate.ps1
# macOS/Linux:
source .venv/bin/activate
```

### 2. Install dependencies

```bash
pip install -r requirements.txt
```

### 3. Add the source CSVs

Place the six files listed above in `data/raw/`.

### 4. Run the pipeline

```bash
python src/pipeline.py
```

The pipeline writes curated CSVs and a data-quality report to `data/processed/` and `reports/`. It checks for missing required files and reports data-quality issues rather than silently deleting records.

### Optional: market-basket analysis

Install the optional package:

```bash
pip install mlxtend
```

Then run:

```bash
python src/market_basket.py --max-orders 50000 --min-support 0.01 --min-confidence 0.10
```

Association rules can be computationally expensive. Start with a manageable order sample and tune thresholds after inspecting sparsity.

## Repository structure

```text
retailpulse360/
├── README.md
├── requirements.txt
├── .gitignore
├── LICENSE
├── data/
│   ├── raw/                 # Put downloaded source files here; do not commit them
│   └── processed/           # Generated outputs; ignored by Git
├── docs/
│   ├── DATA_DICTIONARY.md
│   ├── FORMULAS.md
│   ├── POWER_QUERY.md
│   └── DASHBOARD_BLUEPRINT.md
├── reports/                 # Generated quality report; ignored by Git
├── sql/
│   └── analysis.sql
└── src/
    ├── pipeline.py
    └── market_basket.py
```

## Core metric definitions

| Metric | Definition |
|---|---|
| Product lines | Number of observed rows in an order-products table |
| Observed basket size | Product lines divided by distinct orders represented in that product-lines table |
| Reorder rate | Valid product lines with `reordered = 1` divided by valid `reordered` flags |
| Repeat customer rate | Customers with at least two rows/orders in the selected `orders` population divided by customers in that population |
| Product popularity | Count of observed product lines for each product |
| Support(A, B) | Eligible orders containing both A and B divided by eligible orders |
| Confidence(A → B) | Orders containing both A and B divided by orders containing A |
| Lift(A → B) | Confidence(A → B) divided by support(B) |

Metric names deliberately say “observed” where product-line labels may be incomplete for some competition splits.

## Dashboard plan

1. **Executive Overview:** observed orders, customers, basket size, reorder rate.
2. **Product Intelligence:** most frequently observed products, aisle and department mix.
3. **Customer Behavior:** order count distribution, repeat-order rate, days between orders.
4. **Shopping Patterns:** orders by hour and weekday code.
5. **Basket Analysis:** support, confidence, lift, and top association rules.
6. **Data Quality:** missing values, duplicate keys, invalid ranges, orphan foreign keys.

See [`docs/DASHBOARD_BLUEPRINT.md`](docs/DASHBOARD_BLUEPRINT.md) for visuals and measure mapping.

## Important interpretation notes

- `order_dow` is a coded weekday, not a transaction date.
- `order_hour_of_day` supports hour-of-day analysis, not calendar-time trends.
- `days_since_prior_order` can legitimately be null, especially for a user's first recorded order.
- `reordered` is a product-line flag, not a customer retention label.
- `add_to_cart_order` is cart position, not product quantity.
- The `test` split does not provide labeled product lines in the standard competition release; do not interpret missing test labels as empty baskets.
- Repeat customer rate depends on the selected order population and should not be described as period-based retention.
- A purchase-line count is not a sales-unit count or revenue measure.

## Reproducibility checklist

- Record the source files and their row counts.
- Keep the original raw files unchanged.
- Review `reports/data_quality_summary.csv` before using the curated data.
- Confirm joins do not multiply fact rows.
- Use the same source split and filters when reconciling Python, SQL, Excel, and Power BI.
- Document any excluded rows and the reason for exclusion.

## License

Code in this repository is released under the MIT License; see [`LICENSE`](LICENSE). Dataset rights remain with the dataset provider and are subject to Kaggle's terms.
