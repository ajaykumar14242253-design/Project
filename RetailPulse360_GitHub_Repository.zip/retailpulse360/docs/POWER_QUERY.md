# Power Query (M) Reference

## Append prior and train while preserving split

Assumes queries named `Prior` and `Train` already exist.

```powerquery
let
    PriorTagged = Table.AddColumn(Prior, "source_split", each "prior", type text),
    TrainTagged = Table.AddColumn(Train, "source_split", each "train", type text),
    Combined = Table.Combine({PriorTagged, TrainTagged})
in
    Combined
```

## Detect duplicate order-product keys

```powerquery
let
    Grouped = Table.Group(
        OrderProducts,
        {"order_id", "product_id"},
        {{"row_count", each Table.RowCount(_), Int64.Type}}
    ),
    Duplicates = Table.SelectRows(Grouped, each [row_count] > 1)
in
    Duplicates
```

## Flag invalid order hours

```powerquery
= Table.AddColumn(
    Orders,
    "hour_quality",
    each if [order_hour_of_day] = null then "Missing"
         else if [order_hour_of_day] < 0 or [order_hour_of_day] > 23 then "Invalid"
         else "Pass",
    type text
)
```

## Merge product lookup

```powerquery
let
    Joined = Table.NestedJoin(
        OrderProducts, {"product_id"},
        Products, {"product_id"},
        "ProductLookup", JoinKind.LeftOuter
    ),
    Expanded = Table.ExpandTableColumn(
        Joined, "ProductLookup",
        {"product_name", "aisle_id", "department_id"},
        {"product_name", "aisle_id", "department_id"}
    )
in
    Expanded
```

Always check row counts before and after merges. A lookup table should have unique join keys; otherwise, a merge can multiply fact rows.
