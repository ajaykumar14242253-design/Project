# Data Dictionary

## Source tables

| File | Grain | Key | Use |
|---|---|---|---|
| `orders.csv` | One row per order | `order_id` | Customer order sequence and shopping time patterns |
| `order_products__prior.csv` | One row per product in a prior order | (`order_id`, `product_id`) | Historical basket and reorder analysis |
| `order_products__train.csv` | One row per product in a labeled training order | (`order_id`, `product_id`) | Labeled training-split analysis |
| `products.csv` | One row per catalog product | `product_id` | Product names and category IDs |
| `aisles.csv` | One row per aisle | `aisle_id` | Aisle labels |
| `departments.csv` | One row per department | `department_id` | Department labels |
| `sample_submission.csv` | Submission template rows | `order_id` | Competition submission formatting, not ground-truth product lines |

## Important fields

### `orders.csv`

- `order_id`: order identifier.
- `user_id`: customer identifier.
- `eval_set`: competition split label (commonly prior/train/test).
- `order_number`: sequential order number for the user.
- `order_dow`: coded day of week, 0–6.
- `order_hour_of_day`: hour of day, 0–23.
- `days_since_prior_order`: days since previous order; null can be expected.

### Order-product tables

- `order_id`: order identifier.
- `product_id`: product identifier.
- `add_to_cart_order`: position in which the product was added to cart; not quantity.
- `reordered`: 1 if the product was reordered according to the dataset's definition, otherwise 0.

### Product lookup

- `product_id`: product identifier.
- `product_name`: product label.
- `aisle_id`: aisle key.
- `department_id`: department key.

## Relationship model

```text
Orders (1) ─────── (*) OrderProducts (*) ─────── (1) Products
                                                │
                                                ├── (*) → (1) Aisles
                                                └── (*) → (1) Departments
```

Recommended Power BI relationships:

- `Orders[order_id]` → `OrderProducts[order_id]`
- `Products[product_id]` → `OrderProducts[product_id]`
- `Aisles[aisle_id]` → `Products[aisle_id]`
- `Departments[department_id]` → `Products[department_id]`

Use one-to-many relationships and single-direction dimension filtering where possible.

## Scope limitations

No product price, revenue, cost, discount, promotion, marketing, region, or transaction-date fields are included in the standard files. Do not calculate financial KPIs or calendar-year growth without adding an appropriate external source.
