# Dashboard Blueprint

## Page 1 — Executive Overview

**Purpose:** give a quick, truthful summary of observed shopping behavior.

Cards:
- Total orders in selected `orders` population
- Unique customers in selected `orders` population
- Product lines in selected order-products population
- Average observed basket size
- Reorder rate

Visuals:
- Orders by hour
- Orders by weekday code
- Prior vs train split comparison (only when both are deliberately included)

## Page 2 — Product Intelligence

Visuals:
- Top 10/20 products by product-line count
- Department share of product lines
- Aisle share of product lines
- Reorder rate by department/product, with minimum-volume context

Do not call product-line count “revenue” or “units sold.”

## Page 3 — Customer Behavior

Visuals:
- Distribution of orders per user
- Repeat customer rate (at least two orders in selected population)
- Average/median `days_since_prior_order`
- Customer-level order-count table

Do not call this monthly retention: no calendar transaction date is supplied.

## Page 4 — Shopping Patterns

Visuals:
- Distinct orders by `order_hour_of_day`
- Distinct orders by `order_dow`
- Average cart position by department, if useful

Use the dataset's weekday code labels consistently and document the 0–6 mapping used.

## Page 5 — Basket Analysis

Visuals:
- Top association rules by lift
- Support vs confidence scatter plot
- Rule detail table: antecedent, consequent, support, confidence, lift, leverage

Show support/count context to avoid overemphasizing rare pairs.

## Page 6 — Data Quality

Cards:
- Source row counts
- Failed checks
- Duplicate-key rows
- Orphan foreign-key rows
- Missing-value rate

Tables:
- Check name, status, details
- Missing values by table/column
- Invalid values by field

## Global slicers

- Source split (`prior` / `train`)
- Department
- Aisle
- Product

Only show a slicer if the model relationships support it and the population semantics are clear.

## Model

`Orders` (1) → (*) `OrderProducts` (*) ← (1) `Products`; `Products` relates many-to-one to `Aisles` and `Departments`.

Use `source_split` on the fact table. Keep the original source CSVs immutable.
