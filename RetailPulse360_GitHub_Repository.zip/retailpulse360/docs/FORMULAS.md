# Formula Reference

All formulas below should be calculated against a clearly defined population. When comparing tools, use the same table, split, filters, and denominator.

## 1. Data-quality formulas

- **Missing rate:** `missing cells in column / total rows × 100`
- **Completeness rate:** `(total rows − missing cells) / total rows × 100`
- **Extra duplicate-key rows:** number of repeated key occurrences beyond the first occurrence.
- **Foreign-key match rate:** matched non-null foreign keys / all non-null foreign keys × 100.
- **Reconciliation difference:** source row count − output row count.

### Validations

| Table | Key / field | Rule |
|---|---|---|
| Orders | `order_id` | Unique, non-null |
| Orders | `order_number` | Integer ≥ 1 |
| Orders | `order_dow` | 0 through 6 |
| Orders | `order_hour_of_day` | 0 through 23 |
| Orders | `days_since_prior_order` | Null allowed; otherwise ≥ 0 |
| Order-products | (`order_id`, `product_id`) | Expected unique pair |
| Order-products | `add_to_cart_order` | Integer ≥ 1 |
| Order-products | `reordered` | 0 or 1 |
| Products | `product_id` | Unique, non-null |
| Products | `aisle_id`, `department_id` | Must match lookup tables |

Do not automatically drop duplicate keys or fill all nulls with zero. Inspect, document, and decide.

## 2. Core analytics

Let `L` be observed product-line rows and `O` be distinct orders represented by those lines.

- **Observed basket size:** `L / O`
- **Reorder rate:** `count(reordered = 1) / count(valid reordered flags)`
- **Product popularity:** count of product-line rows for each product.
- **Department share:** product-line rows in department / all product-line rows in the selected population.
- **Average orders per customer:** distinct orders / distinct customers in the selected `orders` population.
- **Repeat customer rate:** customers with at least 2 distinct orders / customers in the selected `orders` population.
- **Average days between orders:** average of non-null `days_since_prior_order`.
- **Average cart position:** average `add_to_cart_order` (interpret as cart position, not quantity).

## 3. Market-basket analysis

Let `N` be eligible orders; `n(A)` orders containing A; `n(B)` orders containing B; and `n(A,B)` orders containing both.

\[
Support(A)=\frac{n(A)}{N}
\]

\[
Support(A,B)=\frac{n(A,B)}{N}
\]

\[
Confidence(A\rightarrow B)=\frac{n(A,B)}{n(A)}
\]

\[
Lift(A\rightarrow B)=\frac{Confidence(A\rightarrow B)}{Support(B)}
\]

\[
Leverage(A,B)=Support(A,B)-Support(A)Support(B)
\]

\[
Conviction(A\rightarrow B)=\frac{1-Support(B)}{1-Confidence(A\rightarrow B)}
\]

When confidence equals 1, conviction's denominator is zero; report infinity/undefined according to the implementation.

## 4. Power BI DAX

Assumed table names: `Orders`, `OrderProducts`, `Products`, `Aisles`, `Departments`.

```dax
Total Orders =
DISTINCTCOUNT ( Orders[order_id] )

Unique Customers =
DISTINCTCOUNT ( Orders[user_id] )

Product Lines =
COUNTROWS ( OrderProducts )

Orders With Observed Product Lines =
DISTINCTCOUNT ( OrderProducts[order_id] )

Distinct Products in Observed Lines =
DISTINCTCOUNT ( OrderProducts[product_id] )

Average Observed Basket Size =
DIVIDE (
    [Product Lines],
    [Orders With Observed Product Lines],
    BLANK()
)

Valid Reorder Lines =
CALCULATE (
    COUNTROWS ( OrderProducts ),
    OrderProducts[reordered] IN { 0, 1 }
)

Reordered Lines =
CALCULATE (
    COUNTROWS ( OrderProducts ),
    OrderProducts[reordered] = 1
)

Reorder Rate =
DIVIDE ( [Reordered Lines], [Valid Reorder Lines], BLANK() )

Average Orders per Customer =
DIVIDE ( [Total Orders], [Unique Customers], BLANK() )

Customers with 2+ Orders =
COUNTROWS (
    FILTER (
        VALUES ( Orders[user_id] ),
        CALCULATE ( DISTINCTCOUNT ( Orders[order_id] ) ) >= 2
    )
)

Repeat Customer Rate =
DIVIDE ( [Customers with 2+ Orders], [Unique Customers], BLANK() )

Average Days Between Orders =
AVERAGE ( Orders[days_since_prior_order] )

Product Purchase Lines =
COUNTROWS ( OrderProducts )

Product Rank =
RANKX (
    ALLSELECTED ( Products[product_id] ),
    [Product Purchase Lines],
    ,
    DESC,
    DENSE
)

Department Product-Line Share =
DIVIDE (
    [Product Purchase Lines],
    CALCULATE (
        [Product Purchase Lines],
        REMOVEFILTERS ( Departments )
    ),
    BLANK()
)
```

Format rate measures as percentages in Power BI; do not multiply DAX rate measures by 100 unless you intentionally want a 0–100 number.

## 5. Excel examples

Assume Excel Tables named `Orders` and `OrderProducts`.

```excel
=COUNTA(UNIQUE(FILTER(Orders[order_id],Orders[order_id]<>"")))
```
Distinct order count in modern Excel.

```excel
=COUNTA(UNIQUE(FILTER(Orders[user_id],Orders[user_id]<>"")))
```
Distinct customer count.

```excel
=COUNTIF(OrderProducts[reordered],1)/COUNT(OrderProducts[reordered])
```
Reorder rate, assuming all nonblank flags are valid 0/1.

```excel
=COUNTIF(OrderProducts[product_id],A2)
```
Product-line count for the product ID in `A2`.

```excel
=COUNTIF(Orders[order_hour_of_day],A2)
```
Order count by hour when `A2` contains the hour code and each order ID occurs once in `Orders`.

## 6. Unsupported measures without extra data

Do not calculate or label these as actual results from Instacart alone:

- Net sales / revenue
- Product cost / gross profit / contribution margin
- Discount depth / promotion ROI / marketing ROI
- Regional or channel sales
- Currency-based customer lifetime value
- Year-over-year sales growth

They require compatible price, cost, marketing, geography, or transaction-date data.
