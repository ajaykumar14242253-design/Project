-- RetailPulse 360: SQL examples.
-- Table names assume CSVs have been imported into a SQL database.
-- Syntax uses LIMIT (PostgreSQL / SQLite / MySQL); adapt for SQL Server as needed.

-- 1. Source row counts
SELECT 'orders' AS table_name, COUNT(*) AS row_count FROM orders
UNION ALL SELECT 'order_products_prior', COUNT(*) FROM order_products_prior
UNION ALL SELECT 'order_products_train', COUNT(*) FROM order_products_train
UNION ALL SELECT 'products', COUNT(*) FROM products
UNION ALL SELECT 'aisles', COUNT(*) FROM aisles
UNION ALL SELECT 'departments', COUNT(*) FROM departments;

-- 2. Duplicate primary keys
SELECT order_id, COUNT(*) AS row_count
FROM orders
GROUP BY order_id
HAVING COUNT(*) > 1;

-- 3. Duplicate order-product composite keys
SELECT order_id, product_id, COUNT(*) AS row_count
FROM order_products_prior
GROUP BY order_id, product_id
HAVING COUNT(*) > 1;

-- 4. Reorder rate: valid binary flags only
SELECT
    SUM(CASE WHEN reordered = 1 THEN 1.0 ELSE 0.0 END)
    / NULLIF(SUM(CASE WHEN reordered IN (0, 1) THEN 1.0 ELSE 0.0 END), 0)
    AS reorder_rate
FROM order_products_prior;

-- 5. Average observed basket size
WITH basket_sizes AS (
    SELECT order_id, COUNT(*) AS product_lines
    FROM order_products_prior
    GROUP BY order_id
)
SELECT AVG(product_lines * 1.0) AS average_observed_basket_size
FROM basket_sizes;

-- 6. Top 20 products by observed product-line count
SELECT p.product_id, p.product_name, COUNT(*) AS product_line_count
FROM order_products_prior op
JOIN products p ON p.product_id = op.product_id
GROUP BY p.product_id, p.product_name
ORDER BY product_line_count DESC
LIMIT 20;

-- 7. Orders by hour
SELECT order_hour_of_day, COUNT(DISTINCT order_id) AS order_count
FROM orders
GROUP BY order_hour_of_day
ORDER BY order_hour_of_day;

-- 8. Repeat customer rate in the selected orders table
WITH customer_counts AS (
    SELECT user_id, COUNT(DISTINCT order_id) AS order_count
    FROM orders
    GROUP BY user_id
)
SELECT
    SUM(CASE WHEN order_count >= 2 THEN 1.0 ELSE 0.0 END)
    / NULLIF(COUNT(*), 0) AS repeat_customer_rate
FROM customer_counts;

-- 9. Orphan product references in prior lines
SELECT op.*
FROM order_products_prior op
LEFT JOIN products p ON p.product_id = op.product_id
WHERE p.product_id IS NULL;

-- 10. Frequent co-purchased pairs. Pair count is distinct orders.
SELECT a.product_id AS product_a, b.product_id AS product_b,
       COUNT(DISTINCT a.order_id) AS cooccurring_orders
FROM order_products_prior a
JOIN order_products_prior b
  ON a.order_id = b.order_id
 AND a.product_id < b.product_id
GROUP BY a.product_id, b.product_id
HAVING COUNT(DISTINCT a.order_id) >= 20
ORDER BY cooccurring_orders DESC
LIMIT 100;
