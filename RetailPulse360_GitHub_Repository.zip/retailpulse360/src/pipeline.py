"""Validate and prepare Instacart data for RetailPulse 360.

Run from the repository root:
    python src/pipeline.py
"""
from pathlib import Path
import json
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
RAW = ROOT / "data" / "raw"
OUT = ROOT / "data" / "processed"
REPORTS = ROOT / "reports"

REQUIRED_FILES = {
    "orders": "orders.csv",
    "prior": "order_products__prior.csv",
    "train": "order_products__train.csv",
    "products": "products.csv",
    "aisles": "aisles.csv",
    "departments": "departments.csv",
}

def load_sources():
    missing = [filename for filename in REQUIRED_FILES.values() if not (RAW / filename).exists()]
    if missing:
        raise FileNotFoundError(
            "Missing required CSV file(s) in data/raw/: " + ", ".join(missing)
        )
    return {name: pd.read_csv(RAW / filename) for name, filename in REQUIRED_FILES.items()}

def table_profile(name, df):
    return {
        "table": name,
        "rows": int(len(df)),
        "columns": int(len(df.columns)),
        "missing_cells": int(df.isna().sum().sum()),
        "duplicate_rows": int(df.duplicated().sum()),
    }

def duplicate_key_count(df, key_columns):
    return int(df.duplicated(key_columns).sum())

def build_quality_report(tables):
    orders = tables["orders"]
    prior = tables["prior"]
    train = tables["train"]
    products = tables["products"]
    aisles = tables["aisles"]
    departments = tables["departments"]

    profiles = [table_profile(name, df) for name, df in tables.items()]
    checks = []

    def add_check(name, passed, details):
        checks.append({
            "check": name,
            "status": "PASS" if passed else "FAIL",
            "details": details,
        })

    add_check(
        "orders.order_id unique",
        duplicate_key_count(orders, ["order_id"]) == 0,
        f"extra duplicate keys={duplicate_key_count(orders, ['order_id'])}",
    )
    add_check(
        "products.product_id unique",
        duplicate_key_count(products, ["product_id"]) == 0,
        f"extra duplicate keys={duplicate_key_count(products, ['product_id'])}",
    )
    add_check(
        "aisles.aisle_id unique",
        duplicate_key_count(aisles, ["aisle_id"]) == 0,
        f"extra duplicate keys={duplicate_key_count(aisles, ['aisle_id'])}",
    )
    add_check(
        "departments.department_id unique",
        duplicate_key_count(departments, ["department_id"]) == 0,
        f"extra duplicate keys={duplicate_key_count(departments, ['department_id'])}",
    )

    for split_name, lines in [("prior", prior), ("train", train)]:
        dupes = duplicate_key_count(lines, ["order_id", "product_id"])
        add_check(
            f"{split_name} order-product key unique",
            dupes == 0,
            f"extra duplicate composite keys={dupes}",
        )
        bad_reordered = int((~lines["reordered"].isin([0, 1])).sum())
        add_check(
            f"{split_name} reordered flag is binary",
            bad_reordered == 0,
            f"invalid or missing flags={bad_reordered}",
        )
        orphan_orders = int((~lines["order_id"].isin(orders["order_id"])).sum())
        orphan_products = int((~lines["product_id"].isin(products["product_id"])).sum())
        add_check(
            f"{split_name} order foreign keys match",
            orphan_orders == 0,
            f"unmatched rows={orphan_orders}",
        )
        add_check(
            f"{split_name} product foreign keys match",
            orphan_products == 0,
            f"unmatched rows={orphan_products}",
        )

    bad_hours = int(
        (orders["order_hour_of_day"].isna()
         | ~orders["order_hour_of_day"].between(0, 23)).sum()
    )
    bad_dow = int(
        (orders["order_dow"].isna()
         | ~orders["order_dow"].between(0, 6)).sum()
    )
    add_check("orders hour range 0-23", bad_hours == 0, f"invalid rows={bad_hours}")
    add_check("orders weekday range 0-6", bad_dow == 0, f"invalid rows={bad_dow}")

    orphan_aisles = int((~products["aisle_id"].isin(aisles["aisle_id"])).sum())
    orphan_departments = int((~products["department_id"].isin(departments["department_id"])).sum())
    add_check("product aisle keys match", orphan_aisles == 0, f"unmatched product rows={orphan_aisles}")
    add_check(
        "product department keys match",
        orphan_departments == 0,
        f"unmatched product rows={orphan_departments}",
    )
    return pd.DataFrame(profiles), pd.DataFrame(checks)

def main():
    OUT.mkdir(parents=True, exist_ok=True)
    REPORTS.mkdir(parents=True, exist_ok=True)
    tables = load_sources()

    profiles, checks = build_quality_report(tables)
    profiles.to_csv(REPORTS / "table_profile.csv", index=False)
    checks.to_csv(REPORTS / "data_quality_summary.csv", index=False)

    # Preserve source split and avoid mutating the raw input files.
    lines = pd.concat(
        [
            tables["prior"].assign(source_split="prior"),
            tables["train"].assign(source_split="train"),
        ],
        ignore_index=True,
    )

    # Keep this as an enriched line-level fact table; do not aggregate before joins.
    enriched = lines.merge(
        tables["products"], on="product_id", how="left",
        validate="many_to_one", indicator="product_match"
    )
    enriched = enriched.merge(
        tables["orders"][
            [
                "order_id", "user_id", "eval_set", "order_number",
                "order_dow", "order_hour_of_day", "days_since_prior_order",
            ]
        ],
        on="order_id", how="left", validate="many_to_one",
        indicator="order_match"
    )
    enriched = enriched.merge(
        tables["aisles"], on="aisle_id", how="left", validate="many_to_one"
    )
    enriched = enriched.merge(
        tables["departments"], on="department_id", how="left",
        validate="many_to_one"
    )

    # A failed key check is surfaced in the report. Do not silently drop rows.
    lines.to_csv(OUT / "order_products_combined.csv", index=False)
    enriched.to_csv(OUT / "product_lines_enriched.csv", index=False)

    prior = tables["prior"]
    prior_order_count = int(prior["order_id"].nunique())
    valid_flags = prior["reordered"].isin([0, 1])
    summary = {
        "prior_product_lines": int(len(prior)),
        "prior_orders_with_observed_lines": prior_order_count,
        "prior_unique_products": int(prior["product_id"].nunique()),
        "prior_reorder_rate": (
            float(prior.loc[valid_flags, "reordered"].eq(1).mean())
            if valid_flags.any() else None
        ),
        "prior_average_observed_basket_size": (
            float(len(prior) / prior_order_count) if prior_order_count else None
        ),
        "orders_table_distinct_orders": int(tables["orders"]["order_id"].nunique()),
        "orders_table_distinct_customers": int(tables["orders"]["user_id"].nunique()),
    }
    (REPORTS / "kpi_summary.json").write_text(
        json.dumps(summary, indent=2), encoding="utf-8"
    )
    print("Pipeline complete.")
    print(f"Quality checks: {checks['status'].value_counts().to_dict()}")
    print(f"Outputs: {OUT}")
    print(f"Reports: {REPORTS}")

if __name__ == "__main__":
    main()
