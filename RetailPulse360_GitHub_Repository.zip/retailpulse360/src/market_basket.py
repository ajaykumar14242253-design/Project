"""Optional association-rule mining on prior order baskets."""
from pathlib import Path
import argparse
import pandas as pd

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--max-orders", type=int, default=50000)
    parser.add_argument("--min-support", type=float, default=0.01)
    parser.add_argument("--min-confidence", type=float, default=0.10)
    args = parser.parse_args()

    try:
        from mlxtend.frequent_patterns import apriori, association_rules
    except ImportError as exc:
        raise SystemExit("Install optional dependency first: pip install mlxtend") from exc

    root = Path(__file__).resolve().parents[1]
    path = root / "data" / "raw" / "order_products__prior.csv"
    if not path.exists():
        raise FileNotFoundError(f"Place order_products__prior.csv at {path}")

    lines = pd.read_csv(path, usecols=["order_id", "product_id"])
    # Deterministic sample by sorted unique order ID, not a random claim about population.
    selected_ids = sorted(lines["order_id"].drop_duplicates())[:args.max_orders]
    lines = lines[lines["order_id"].isin(selected_ids)]

    basket = (
        lines.assign(present=1)
        .pivot_table(
            index="order_id", columns="product_id", values="present",
            aggfunc="max", fill_value=0
        )
        .astype(bool)
    )
    itemsets = apriori(basket, min_support=args.min_support, use_colnames=True)
    if itemsets.empty:
        print("No frequent itemsets found. Lower --min-support or increase --max-orders.")
        return

    rules = association_rules(
        itemsets, metric="confidence", min_threshold=args.min_confidence
    ).sort_values(["lift", "confidence"], ascending=False)

    out = root / "data" / "processed"
    out.mkdir(parents=True, exist_ok=True)
    itemsets.to_csv(out / "frequent_itemsets.csv", index=False)
    rules.to_csv(out / "association_rules.csv", index=False)
    print(f"Analyzed {basket.shape[0]:,} orders and {basket.shape[1]:,} distinct products.")
    print(f"Saved rules to {out / 'association_rules.csv'}")

if __name__ == "__main__":
    main()
